"""
ID посылки: 88341982

-- ПРИНЦИП РАБОТЫ --

Принцип работы основан на структуре Хеш Таблице.

В основе таблице лежит массив массивов. Индексация по первому происходит по хеш функции (простейшее выражение) для равномерного заполнения и предотвращения коллизий.

Колизии разрешаются методом цепочек. Для этого в каждой ячейки массива расположен массив. При равномерном заполнении таблицы, массив каждой чейки не будет содержать элементов больше n//m, где n-размер входных данных, а m-размер хеш таблицы

-- ДОКАЗАТЕЛЬСТВО КОРРЕКТНОСТИ --

Алгоритм обеспечиват развномерное заполнение таблицы, что обеспечиват одинаковую сложность доступа к элементам в среднем

-- ВРЕМЕННАЯ СЛОЖНОСТЬ --

Временная сложность в среднем O(1), а в худшем случае O(n/m)

-- ПРОСТРАНСТВЕННАЯ СЛОЖНОСТЬ --

Пространственная сложность -  O(n) памяти.

"""
class HashMap():

  def __init__(self, n):
    self.storage = [[] for _ in range(n // 2)]
    self.size = n // 2

  def put_m(self, key, value):
    hash_key = (key % self.size + self.size) % self.size
    massive = self.storage[hash_key]
    for pair in massive:
      if pair[0] == key:
        pair[1] = value
        break
    else:
      self.storage[hash_key].append([key, value])

  def get_m(self, key):
    hash_key = (key % self.size + self.size) % self.size
    massive = self.storage[hash_key]
    for pair in massive:
      if pair[0] == key:
        print(pair[1])
        break
    else:
      print(None)

  def delete_m(self, key):
    hash_key = (key % self.size + self.size) % self.size
    massive = self.storage[hash_key]
    for pair in massive:
      if pair[0] == key:
        print(pair[1])
        massive.remove(pair)
        break
    else:
      print(None)

if __name__ == "__main__":

  n = int(input())
  hash_map = HashMap(n)
  for _ in range(n):
    command = input().strip().split()

    if command[0] == "get":
      hash_map.get_m(int(command[1]))

    elif command[0] == "put":
      hash_map.put_m(int(command[1]), int(command[2]))

    elif command[0] == "delete":
      hash_map.delete_m(int(command[1]))

    # print(hash_map.storage)

